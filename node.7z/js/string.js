// ✅ Required to take input from user
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

readline.question("Enter a string: ", function (inputStr) {
    stringOperations(inputStr);
    readline.close();
});

// ✅ Main function with all sub operations
function stringOperations(str) {
    console.log("Original String:", str);

    printLength(str);
    printUpperCase(str);
    printLowerCase(str);
    printReverse(str);
    printEachCharacter(str);
    countVowelsAndConsonants(str);
    printVowelsAndConsonants(str);
    isPalindrome(str);
    countWords(str); // works better with space-separated strings
    replaceVowelsWithStar(str);
    sortCharacters(str);
}

// ✅ Function to print length
function printLength(str) {
    let length = 0;
    for (let i = 0; str[i] !== undefined; i++) {
        length++;
    }
    console.log("Length of string:", length);
}

// ✅ Function to convert to uppercase
function printUpperCase(str) {
    let result = "";
    for (let i = 0; i < str.length; i++) {
        let ch = str[i];
        if (ch >= 'a' && ch <= 'z') {
            result += String.fromCharCode(ch.charCodeAt(0) - 32);
        } else {
            result += ch;
        }
    }
    console.log("Uppercase:", result);
}

// ✅ Function to convert to lowercase
function printLowerCase(str) {
    let result = "";
    for (let i = 0; i < str.length; i++) {
        let ch = str[i];
        if (ch >= 'A' && ch <= 'Z') {
            result += String.fromCharCode(ch.charCodeAt(0) + 32);
        } else {
            result += ch;
        }
    }
    console.log("Lowercase:", result);
}

// ✅ Function to reverse the string
function printReverse(str) {
    let reversed = "";
    for (let i = str.length - 1; i >= 0; i--) {
        reversed += str[i];
    }
    console.log("Reversed:", reversed);
}

// ✅ Function to print each character
function printEachCharacter(str) {
    console.log("Characters in the string:");
    for (let i = 0; i < str.length; i++) {
        console.log(str[i]);
    }
}

// ✅ Function to count vowels and consonants
function countVowelsAndConsonants(str) {
    let vCount = 0, cCount = 0;
    for (let i = 0; i < str.length; i++) {
        let ch = str[i];
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            let lower = ch.toLowerCase();
            if (lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u') {
                vCount++;
            } else {
                cCount++;
            }
        }
    }
    console.log("Vowels:", vCount);
    console.log("Consonants:", cCount);
}

// ✅ Function to print vowels and consonants
function printVowelsAndConsonants(str) {
    console.log("Vowels:");
    for (let i = 0; i < str.length; i++) {
        let ch = str[i].toLowerCase();
        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
            console.log(str[i]);
        }
    }

    console.log("Consonants:");
    for (let i = 0; i < str.length; i++) {
        let ch = str[i].toLowerCase();
        if ((ch >= 'a' && ch <= 'z') &&
            !(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')) {
            console.log(str[i]);
        }
    }
}

// ✅ Function to check if string is palindrome
function isPalindrome(str) {
    let lowerStr = "";
    for (let i = 0; i < str.length; i++) {
        let ch = str[i];
        if (ch >= 'A' && ch <= 'Z') {
            lowerStr += String.fromCharCode(ch.charCodeAt(0) + 32);
        } else {
            lowerStr += ch;
        }
    }

    let reversed = "";
    for (let i = lowerStr.length - 1; i >= 0; i--) {
        reversed += lowerStr[i];
    }

    if (lowerStr == reversed) {
        console.log("Is Palindrome? Yes");
    } else {
        console.log("Is Palindrome? No");
    }
}

// ✅ Function to count words
function countWords(str) {
    let count = 0;
    let inWord = false;
    for (let i = 0; i < str.length; i++) {
        if (str[i] !== ' ' && !inWord) {
            inWord = true;
            count++;
        } else if (str[i] === ' ') {
            inWord = false;
        }
    }
    console.log("Word count:", count);
}

// ✅ Function to replace vowels with '*'
function replaceVowelsWithStar(str) {
    let result = "";
    for (let i = 0; i < str.length; i++) {
        let ch = str[i];
        let lower = ch.toLowerCase();
        if (lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u') {
            result += '*';
        } else {
            result += ch;
        }
    }
    console.log("Vowels replaced with '*':", result);
}

// ✅ Function to sort characters
function sortCharacters(str) {
    let arr = [];
    for (let i = 0; i < str.length; i++) {
        arr.push(str[i]);
    }

    // Simple bubble sort
    for (let i = 0; i < arr.length - 1; i++) {
        for (let j = 0; j < arr.length - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                let temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    let sorted = "";
    for (let i = 0; i < arr.length; i++) {
        sorted += arr[i];
    }

    console.log("Sorted characters:", sorted);
}
