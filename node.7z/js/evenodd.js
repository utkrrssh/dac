const readline = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout
});

function checkEvenOdd(num) {
  if (num % 2 === 0) {
    console.log("Even");
  } else {
    console.log("Odd");
  }
}

readline.question("Enter a number: ", (input) => {
  checkEvenOdd(parseInt(input));
  readline.close();
});


// ✅ Required for user input
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

// ✅ Function to print Fibonacci series using only if-else and for
function printFibonacci(n) {
    let a = 0;
    let b = 1;

    // If only 1 term
    if (n === 1) {
        console.log(a);
    }
    // If only 2 terms
    else if (n === 2) {
        console.log(a);
        console.log(b);
    }
    // If more than 2 terms
    else {
        console.log(a);
        console.log(b);
        for (let i = 3; i <= n; i++) {
            let c = a + b;
            console.log(c);
            a = b;
            b = c;
        }
    }
}

// ✅ OPTION 1: User input (default - keep this block if taking input from user)
readline.question("Enter number of terms: ", function (input) {
    const n = parseInt(input);

    if (isNaN(n) || n <= 0) {
        console.log("❌ Please enter a valid positive number.");
    } else {
        console.log("✅ Fibonacci Series:");
        printFibonacci(n);
    }

    readline.close();
});


/*
// ✅ OPTION 2: Hardcoded input (uncomment below and comment the user input block to use this)
const n = 7; // change as needed

if (n <= 0) {
    console.log("❌ Please enter a valid positive number.");
} else {
    console.log("✅ Fibonacci Series:");
    printFibonacci(n);
}
*/
-------------------------------------------------------------------------------------------------------------

// ✅ Node.js required to run this file (use "node swap.js")
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

readline.question("Enter first number (a): ", function (aInput) {
    readline.question("Enter second number (b): ", function (bInput) {
        let a = Number(aInput);
        let b = Number(bInput);

        console.log("Before Swapping: a =", a, ", b =", b);

        // Swapping using a temporary variable
        let temp = a;
        a = b;
        b = temp;

        console.log("After Swapping:  a =", a, ", b =", b);

        readline.close();
    });
});

---------------------------------------------------------------------------------------------------------------------------------------

// ✅ Node.js required to run this file (use "node calculator.js")
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log("\n--- Calculator ---");
console.log("Choose Operation:");
console.log("1. Addition (+)");
console.log("2. Subtraction (-)");
console.log("3. Multiplication (*)");
console.log("4. Division (/)");

readline.question("Enter your choice (1-4): ", function (choice) {
    readline.question("Enter first number: ", function (num1) {
        readline.question("Enter second number: ", function (num2) {
            let a = Number(num1);
            let b = Number(num2);
            let result;

            if (choice == "1") {
                result = a + b;
                console.log("Result:", result);
            } else if (choice == "2") {
                result = a - b;
                console.log("Result:", result);
            } else if (choice == "3") {
                result = a * b;
                console.log("Result:", result);
            } else if (choice == "4") {
                if (b === 0) {
                    console.log("Error: Division by zero!");
                } else {
                    result = a / b;
                    console.log("Result:", result);
                }
            } else {
                console.log("Invalid choice!");
            }

            readline.close();
        });
    });
});
