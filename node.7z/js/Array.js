// ✅ Node.js required to run this file (use "node filename.js")
// 🔽 Load readline module for user input
const readline = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout,
});

// 🔴 Remove this array if you are taking user input
let numbers = [10, 20, 30, 40, 50]; // Hardcoded input array

// 🟢 Remove everything inside this function if using hardcoded input
// function getUserInput() {
//     readline.question("Enter numbers separated by space: ", (input) => {
//         numbers = input.split(" ").map(Number);
//         main(); // Call main after taking input
//         readline.close();
//     });
// }

// Function to print all elements
function printAll() {
    console.log("All Elements:", numbers);
}

// Function to print alternate elements
function printAlternate() {
    console.log("Alternate Elements:");
    for (let i = 0; i < numbers.length; i += 2) {
        console.log(numbers[i]);
    }
}

// Function to reverse the array
function printReverse() {
    console.log("Reversed Array:", [...numbers].reverse());
}

// Function to sort the array
function printSorted() {
    console.log("Sorted Array:", [...numbers].sort((a, b) => a - b));
}

// Function to calculate sum and average
function sumAndAverage() {
    const sum = numbers.reduce((a, b) => a + b, 0);
    const avg = sum / numbers.length;
    console.log(`Sum = ${sum}, Average = ${avg.toFixed(2)}`);
}

// Function to find max and min
function maxAndMin() {
    const max = Math.max(...numbers);
    const min = Math.min(...numbers);
    console.log(`Max = ${max}, Min = ${min}`);
}

// Function to print even and odd numbers
function printEvenOdd() {
    const even = numbers.filter(num => num % 2 === 0);
    const odd = numbers.filter(num => num % 2 !== 0);
    console.log("Even Numbers:", even);
    console.log("Odd Numbers:", odd);
}

// Main function
function main() {
    console.log("\n--- Array Operations ---");
    printAll();
    printAlternate();
    printReverse();
    printSorted();
    sumAndAverage();
    maxAndMin();
    printEvenOdd();
}

// 🔴 Uncomment this if using hardcoded input
main();

// 🟢 Uncomment this if taking input from user
// getUserInput();

--------------------------------------------------------------------------------------------------------------------------------------------------------------

// ✅ Node.js required to run this file (use "node filename.js")
// 🔽 Load readline module for user input
const readline = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout,
});

// 🔴 Remove this array if you are taking user input
let numbers = [10, 20, 30, 40, 50]; // Hardcoded input array

// 🟢 Remove everything inside this function if using hardcoded input
// function getUserInput() {
//     readline.question("Enter numbers separated by space: ", function (input) {
//         let parts = input.split(" ");
//         numbers = [];
//         for (let i = 0; i < parts.length; i++) {
//             numbers.push(Number(parts[i]));
//         }
//         main(); // Call main after taking input
//         readline.close();
//     });
// }

// Function to print all elements
function printAll() {
    console.log("All Elements:");
    for (let i = 0; i < numbers.length; i++) {
        console.log(numbers[i]);
    }
}

// Function to print alternate elements
function printAlternate() {
    console.log("Alternate Elements:");
    for (let i = 0; i < numbers.length; i = i + 2) {
        console.log(numbers[i]);
    }
}

// Function to reverse the array
function printReverse() {
    console.log("Reversed Array:");
    for (let i = numbers.length - 1; i >= 0; i--) {
        console.log(numbers[i]);
    }
}

// Function to sort the array
function printSorted() {
    // Bubble sort
    let sorted = [];
    for (let i = 0; i < numbers.length; i++) {
        sorted[i] = numbers[i];
    }

    for (let i = 0; i < sorted.length - 1; i++) {
        for (let j = 0; j < sorted.length - 1 - i; j++) {
            if (sorted[j] > sorted[j + 1]) {
                let temp = sorted[j];
                sorted[j] = sorted[j + 1];
                sorted[j + 1] = temp;
            }
        }
    }

    console.log("Sorted Array:");
    for (let i = 0; i < sorted.length; i++) {
        console.log(sorted[i]);
    }
}

// Function to calculate sum and average
function sumAndAverage() {
    let sum = 0;
    for (let i = 0; i < numbers.length; i++) {
        sum = sum + numbers[i];
    }
    let avg = sum / numbers.length;
    console.log("Sum =", sum, ", Average =", avg.toFixed(2));
}

// Function to find max and min
function maxAndMin() {
    let max = numbers[0];
    let min = numbers[0];

    for (let i = 1; i < numbers.length; i++) {
        if (numbers[i] > max) {
            max = numbers[i];
        }
        if (numbers[i] < min) {
            min = numbers[i];
        }
    }

    console.log("Max =", max, ", Min =", min);
}

// Function to print even and odd numbers
function printEvenOdd() {
    let even = [];
    let odd = [];

    for (let i = 0; i < numbers.length; i++) {
        if (numbers[i] % 2 === 0) {
            even.push(numbers[i]);
        } else {
            odd.push(numbers[i]);
        }
    }

    console.log("Even Numbers:");
    for (let i = 0; i < even.length; i++) {
        console.log(even[i]);
    }

    console.log("Odd Numbers:");
    for (let i = 0; i < odd.length; i++) {
        console.log(odd[i]);
    }
}

// Main function
function main() {
    console.log("\n--- Array Operations ---");
    printAll();
    printAlternate();
    printReverse();
    printSorted();
    sumAndAverage();
    maxAndMin();
    printEvenOdd();
}

// 🔴 Uncomment this if using hardcoded input
main();

// 🟢 Uncomment this if taking input from user
// getUserInput();
