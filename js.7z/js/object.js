// ===== 1. Create a simple object with properties and print them
let student = {
    name: "Utkarsh",
    age: 23,
    course: "DAC"
};
console.log("Student Details:");
console.log("Name:", student.name);
console.log("Age:", student.age);
console.log("Course:", student.course);

console.log("\n");

// ===== 2. Add new property to an object
student.email = "utkarsh@example.com";
console.log("After adding email:");
console.log(student);

console.log("\n");

// ===== 3. Delete a property from an object
delete student.course;
console.log("After deleting course:");
console.log(student);

console.log("\n");

// ===== 4. Loop through object properties
console.log("Looping through properties:");
for (let key in student) {
    console.log(key + ":", student[key]);
}

console.log("\n");

// ===== 5. Array of objects and display details
let employees = [
    { id: 1, name: "Alice", salary: 30000 },
    { id: 2, name: "Bob", salary: 40000 },
    { id: 3, name: "Charlie", salary: 35000 }
];

console.log("Employee List:");
for (let emp of employees) {
    console.log("ID:", emp.id, "Name:", emp.name, "Salary:", emp.salary);
}

console.log("\n");

// ===== 6. Find an object by property value
let searchName = "Bob";
let foundEmployee = employees.find(emp => emp.name === searchName);
console.log("Employee found with name Bob:", foundEmployee);

console.log("\n");

// ===== 7. Total salary of all employees
let totalSalary = 0;
for (let emp of employees) {
    totalSalary += emp.salary;
}
console.log("Total Salary of Employees:", totalSalary);

console.log("\n");

// ===== 8. Update an object’s property in an array
let updateId = 2;
for (let emp of employees) {
    if (emp.id === updateId) {
        emp.salary = 45000;
    }
}
console.log("Updated Employee List after salary change:");
console.log(employees);



// // Import readline module to take input from user
// const readline = require('readline').createInterface({
//     input: process.stdin,
//     output: process.stdout
// });

// // Create an empty student object
// let student = {};

// // Function to collect input from user
// function getStudentDetails() {
//     readline.question("Enter student name: ", function(name) {
//         student.name = name;

//         readline.question("Enter roll number: ", function(roll) {
//             student.roll = parseInt(roll); // convert to number

//             readline.question("Enter marks out of 100: ", function(marks) {
//                 student.marks = parseFloat(marks); // convert to float

//                 readline.question("Enter department: ", function(dept) {
//                     student.department = dept;

//                     // After collecting all values, display the object
//                     console.log("\n--- Student Details ---");
//                     console.log("Name:", student.name);
//                     console.log("Roll No:", student.roll);
//                     console.log("Marks:", student.marks);
//                     console.log("Department:", student.department);

//                     // You can now do any operations on the object if needed
//                     readline.close();
//                 });
//             });
//         });
//     });
// }

// // Call the function
// getStudentDetails();
