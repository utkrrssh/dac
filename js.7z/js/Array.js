// ✅ Node.js required to run this file (use "node filename.js")
// 🔽 Load readline module for user input
const readline = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout,
});

// 🔴 Remove this array if you are taking user input
let numbers = [10, 20, 30, 40, 50]; // Hardcoded input array

// 🟢 Remove everything inside this function if using hardcoded input
// function getUserInput() {
//     readline.question("Enter numbers separated by space: ", (input) => {
//         numbers = input.split(" ").map(Number);
//         main(); // Call main after taking input
//         readline.close();
//     });
// }

// Function to print all elements
function printAll() {
    console.log("All Elements:", numbers);
}

// Function to print alternate elements
function printAlternate() {
    console.log("Alternate Elements:");
    for (let i = 0; i < numbers.length; i += 2) {
        console.log(numbers[i]);
    }
}

// Function to reverse the array
function printReverse() {
    console.log("Reversed Array:", [...numbers].reverse());
}

// Function to sort the array
function printSorted() {
    console.log("Sorted Array:", [...numbers].sort((a, b) => a - b));
}

// Function to calculate sum and average
function sumAndAverage() {
    const sum = numbers.reduce((a, b) => a + b, 0);
    const avg = sum / numbers.length;
    console.log(`Sum = ${sum}, Average = ${avg.toFixed(2)}`);
}

// Function to find max and min
function maxAndMin() {
    const max = Math.max(...numbers);
    const min = Math.min(...numbers);
    console.log(`Max = ${max}, Min = ${min}`);
}

// Function to print even and odd numbers
function printEvenOdd() {
    const even = numbers.filter(num => num % 2 === 0);
    const odd = numbers.filter(num => num % 2 !== 0);
    console.log("Even Numbers:", even);
    console.log("Odd Numbers:", odd);
}

// Main function
function main() {
    console.log("\n--- Array Operations ---");
    printAll();
    printAlternate();
    printReverse();
    printSorted();
    sumAndAverage();
    maxAndMin();
    printEvenOdd();
}

// 🔴 Uncomment this if using hardcoded input
main();

// 🟢 Uncomment this if taking input from user
// getUserInput();
