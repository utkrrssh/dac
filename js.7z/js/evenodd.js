const readline = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout
});

function checkEvenOdd(num) {
  if (num % 2 === 0) {
    console.log("Even");
  } else {
    console.log("Odd");
  }
}

readline.question("Enter a number: ", (input) => {
  checkEvenOdd(parseInt(input));
  readline.close();
});
